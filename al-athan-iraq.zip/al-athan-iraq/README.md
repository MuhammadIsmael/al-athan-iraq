# Al-Athan Iraq (Android TV)

A from-scratch native Android TV app (Kotlin) for Iraqi prayer times. This is
original code with its own branding — it is **not** derived from or a
repackaging of any existing prayer-times app (e.g. Mawaqit). That's
intentional: modifying and redistributing someone else's app under a new
name/logo would be a copyright violation, so this project builds the same
kind of functionality independently.

## What's included

- **Home screen**: app name, selected city, Gregorian + Hijri date, the 5
  daily prayer times (Fajr, Dhuhr, Asr, Maghrib, Isha) in cards, a live
  countdown to the next prayer, and a "Change City" button for D-pad
  navigation.
- **City picker**: grid of 18 major Iraqi cities (Baghdad, Basra, Mosul,
  Erbil, Najaf, Karbala, Kirkuk, Sulaymaniyah, Duhok, and more) — see
  `City.kt` to add/adjust.
- **Prayer time source**: [Aladhan API](https://aladhan.com/prayer-times-api)
  (free, no key required), calculation method defaults to the Egyptian
  General Authority of Survey (method=2), commonly used across Iraq. You can
  change this in `AladhanApi.kt`.
- **Hijri date**: comes from the same Aladhan API response.
- **Athan (call to prayer) audio**: `AthanScheduler` + `AthanAlarmReceiver`
  schedule an `AlarmManager` alarm for each remaining prayer today and play
  `res/raw/athan.mp3` when it fires.
- **Original branding**: app name "Al-Athan Iraq", a from-scratch vector
  mosque/crescent icon and TV banner in a green/gold theme
  (`ic_launcher_foreground.xml`, `tv_banner.xml`) — no Mawaqit logo or assets
  anywhere in this project.

## ⚠️ Before you build: add a real athan audio file

`app/src/main/res/raw/athan.mp3` is currently a **placeholder text file**,
not real audio — I can't source or embed a specific athan recording for you
without knowing its licensing. Before building:

1. Get an athan recording you have the rights to use (many reciters release
   recordings under permissive licenses — check the terms before using one).
2. Replace `app/src/main/res/raw/athan.mp3` with that file (keep the same
   filename).

Without this, the app runs fine but plays no sound at prayer time (the
receiver fails silently rather than crashing).

## Building the APK

This sandbox doesn't have network access to the Android SDK/Gradle
distribution servers, so I've provided the full source tree but couldn't
compile it here. To build:

1. Install [Android Studio](https://developer.android.com/studio) (Hedgehog
   or newer).
2. Open this project folder (`File > Open`) — Android Studio will fetch the
   Gradle wrapper and dependencies automatically on first sync.
3. Replace `res/raw/athan.mp3` as described above.
4. `Build > Generate Signed Bundle / APK` (or run `./gradlew assembleDebug`
   from a terminal once the wrapper jar has been fetched) to produce an
   installable APK.
5. Sideload onto your Android TV via `adb install app-debug.apk`, or copy to
   a USB drive and install with a file manager app.

## Project structure

```
app/src/main/java/com/alathaniraq/tv/
  data/     City list, Aladhan API client + models, repository
  ui/       MainActivity (home screen), CityPickerActivity
  util/     Prefs, AthanScheduler, AthanAlarmReceiver, BootReceiver, date formatting
app/src/main/res/
  layout/   activity_main.xml, activity_city_picker.xml, item_prayer_card.xml, item_city.xml
  drawable/ Original launcher icon, TV banner, card + button styles
  values/   strings.xml, colors.xml (mosque-green + gold theme), themes.xml
```

## Known limitations / next steps

- Alarms are (re)scheduled only for the *remaining* prayers each time the
  app is opened (or on boot). For a fully "set and forget" install, swap
  `BootReceiver`'s activity launch for a daily `WorkManager` job that
  fetches tomorrow's timings just after midnight and reschedules.
- City list is a fixed set of 18 cities; add more `City(...)` entries in
  `IraqCities.kt` as needed, or wire up a location-based lookup.
- No offline caching yet — the app fetches from Aladhan each time it opens.
- Calculation method defaults to method=2; if you want the method used by a
  specific Iraqi religious authority, check Aladhan's docs for the closest
  match or supply custom angles.
