package com.alathaniraq.tv.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity

/**
 * Shows the branded startup screen (res/drawable-nodpi/splash_screen.png, set as this
 * activity's window background via Theme.AlAthanIraq.Splash) for a short delay, then
 * hands off to MainActivity. No layout is inflated here — the image IS the window
 * background, so there's zero flicker between window-draw and content-draw.
 */
class SplashActivity : ComponentActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private val goToMain = Runnable {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handler.postDelayed(goToMain, SPLASH_DURATION_MS)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(goToMain)
    }

    companion object {
        private const val SPLASH_DURATION_MS = 2000L
    }
}
