package com.alathaniraq.tv.data

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface AladhanApi {

    // method=2 is Egyptian General Authority of Survey, widely used across Iraq.
    // school=0 (Shafi) is default for Asr calculation; adjust if needed for local convention.
    @GET("v1/timings")
    suspend fun getTimings(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("method") method: Int = 2,
        @Query("timestamp") timestamp: Long
    ): AladhanResponse

    companion object {
        private const val BASE_URL = "https://api.aladhan.com/"

        fun create(): AladhanApi {
            val retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
            return retrofit.create(AladhanApi::class.java)
        }
    }
}
