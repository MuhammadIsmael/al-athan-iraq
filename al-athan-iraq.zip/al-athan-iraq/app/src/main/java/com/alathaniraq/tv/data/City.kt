package com.alathaniraq.tv.data

data class City(
    val id: String,
    val displayName: String,
    val latitude: Double,
    val longitude: Double
)

object IraqCities {
    val ALL = listOf(
        City("baghdad", "Baghdad", 33.3152, 44.3661),
        City("basra", "Basra", 30.5085, 47.7835),
        City("mosul", "Mosul", 36.3489, 43.1189),
        City("erbil", "Erbil", 36.1901, 44.0091),
        City("najaf", "Najaf", 31.9958, 44.3288),
        City("karbala", "Karbala", 32.6160, 44.0249),
        City("kirkuk", "Kirkuk", 35.4681, 44.3922),
        City("sulaymaniyah", "Sulaymaniyah", 35.5650, 45.4329),
        City("duhok", "Duhok", 36.8617, 42.9887),
        City("nasiriyah", "Nasiriyah", 31.0439, 46.2578),
        City("amarah", "Amarah", 31.8354, 47.1443),
        City("diwaniyah", "Diwaniyah", 31.9890, 44.9282),
        City("kut", "Kut", 32.5122, 45.8188),
        City("hillah", "Hillah", 32.4839, 44.4342),
        City("ramadi", "Ramadi", 33.4224, 43.3054),
        City("fallujah", "Fallujah", 33.3489, 43.7867),
        City("samarra", "Samarra", 34.1959, 43.8742),
        City("tikrit", "Tikrit", 34.6039, 43.6773)
    )

    fun byId(id: String): City = ALL.firstOrNull { it.id == id } ?: ALL[0]
}
