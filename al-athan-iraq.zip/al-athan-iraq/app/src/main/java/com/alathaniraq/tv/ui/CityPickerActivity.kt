package com.alathaniraq.tv.ui

import android.app.Activity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.leanback.widget.VerticalGridView
import androidx.recyclerview.widget.RecyclerView
import com.alathaniraq.tv.data.City
import com.alathaniraq.tv.data.IraqCities
import com.alathaniraq.tv.databinding.ActivityCityPickerBinding
import com.alathaniraq.tv.databinding.ItemCityBinding
import com.alathaniraq.tv.util.Prefs

class CityPickerActivity : Activity() {

    private lateinit var binding: ActivityCityPickerBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCityPickerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val grid: VerticalGridView = binding.cityGrid
        grid.adapter = CityAdapter(IraqCities.ALL) { city ->
            Prefs.setCityId(this, city.id)
            setResult(RESULT_OK)
            finish()
        }
    }

    private class CityAdapter(
        private val cities: List<City>,
        private val onClick: (City) -> Unit
    ) : RecyclerView.Adapter<CityAdapter.VH>() {

        inner class VH(val binding: ItemCityBinding) : RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val inflater = LayoutInflater.from(parent.context)
            val binding = ItemCityBinding.inflate(inflater, parent, false)
            return VH(binding)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val city = cities[position]
            holder.binding.cityLabel.text = city.displayName
            holder.binding.root.setOnClickListener { onClick(city) }
        }

        override fun getItemCount(): Int = cities.size
    }
}
