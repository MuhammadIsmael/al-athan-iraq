package com.alathaniraq.tv.util

import android.content.Context

object Prefs {
    private const val FILE = "al_athan_iraq_prefs"
    private const val KEY_CITY = "selected_city_id"
    private const val KEY_MOSQUE_NAME = "mosque_name"

    fun getCityId(context: Context): String {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return sp.getString(KEY_CITY, "baghdad") ?: "baghdad"
    }

    fun setCityId(context: Context, cityId: String) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        sp.edit().putString(KEY_CITY, cityId).apply()
    }

    /** Display name for the mosque shown at the top of the home screen. Editable per-install. */
    fun getMosqueName(context: Context): String {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return sp.getString(KEY_MOSQUE_NAME, null) ?: context.getString(com.alathaniraq.tv.R.string.default_mosque_name)
    }

    fun setMosqueName(context: Context, name: String) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        sp.edit().putString(KEY_MOSQUE_NAME, name).apply()
    }
}
