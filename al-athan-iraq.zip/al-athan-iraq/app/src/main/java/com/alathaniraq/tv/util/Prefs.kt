package com.alathaniraq.tv.util

import android.content.Context

object Prefs {
    private const val FILE = "al_athan_iraq_prefs"
    private const val KEY_CITY = "selected_city_id"

    fun getCityId(context: Context): String {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return sp.getString(KEY_CITY, "baghdad") ?: "baghdad"
    }

    fun setCityId(context: Context, cityId: String) {
        val sp = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        sp.edit().putString(KEY_CITY, cityId).apply()
    }
}
