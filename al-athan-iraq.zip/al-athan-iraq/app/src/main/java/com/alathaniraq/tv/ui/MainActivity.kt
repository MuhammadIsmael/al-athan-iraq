package com.alathaniraq.tv.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.lifecycleScope
import com.alathaniraq.tv.R
import com.alathaniraq.tv.data.City
import com.alathaniraq.tv.data.IraqCities
import com.alathaniraq.tv.data.PrayerTimesRepository
import com.alathaniraq.tv.data.Timings
import com.alathaniraq.tv.databinding.ActivityMainBinding
import com.alathaniraq.tv.databinding.ItemPrayerCardBinding
import com.alathaniraq.tv.util.AthanScheduler
import com.alathaniraq.tv.util.DateFormatting
import com.alathaniraq.tv.util.Prefs
import kotlinx.coroutines.launch
import java.util.Calendar
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {

    private lateinit var binding: ActivityMainBinding
    private val repository = PrayerTimesRepository()
    private val handler = Handler(Looper.getMainLooper())
    private var currentTimings: Timings? = null
    private var currentCity: City = IraqCities.ALL[0]

    private val countdownRunnable = object : Runnable {
        override fun run() {
            updateCountdown()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.changeCityButton.setOnClickListener {
            startActivityForResult(Intent(this, CityPickerActivity::class.java), REQUEST_CITY)
        }

        binding.gregorianDate.text = DateFormatting.gregorianToday()
        refresh()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CITY && resultCode == Activity.RESULT_OK) {
            refresh()
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(countdownRunnable)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(countdownRunnable)
    }

    private fun refresh() {
        currentCity = IraqCities.byId(Prefs.getCityId(this))
        binding.cityName.text = currentCity.displayName

        lifecycleScope.launch {
            val result = repository.fetchToday(currentCity)
            result.onSuccess { data ->
                currentTimings = data.timings
                binding.hijriDate.text = DateFormatting.formatHijri(data.date.hijri)
                bindPrayerCard(binding.cardFajr, getString(R.string.fajr), data.timings.fajr)
                bindPrayerCard(binding.cardDhuhr, getString(R.string.dhuhr), data.timings.dhuhr)
                bindPrayerCard(binding.cardAsr, getString(R.string.asr), data.timings.asr)
                bindPrayerCard(binding.cardMaghrib, getString(R.string.maghrib), data.timings.maghrib)
                bindPrayerCard(binding.cardIsha, getString(R.string.isha), data.timings.isha)
                updateCountdown()
                AthanScheduler.scheduleToday(this@MainActivity, data.timings)
            }.onFailure {
                binding.countdown.text = getString(R.string.error_loading)
            }
        }
    }

    private fun bindPrayerCard(cardBinding: ItemPrayerCardBinding, name: String, time: String) {
        cardBinding.prayerName.text = name
        cardBinding.prayerTime.text = time.take(5)
    }

    /** Finds the next upcoming prayer and updates the countdown + card highlighting. */
    private fun updateCountdown() {
        val timings = currentTimings ?: return
        val order = listOf(
            getString(R.string.fajr) to timings.fajr,
            getString(R.string.dhuhr) to timings.dhuhr,
            getString(R.string.asr) to timings.asr,
            getString(R.string.maghrib) to timings.maghrib,
            getString(R.string.isha) to timings.isha
        )

        val now = Calendar.getInstance()
        var nextIndex = -1
        var nextMillis = Long.MAX_VALUE

        order.forEachIndexed { index, (_, time) ->
            val parts = time.take(5).split(":")
            if (parts.size != 2) return@forEachIndexed
            val hour = parts[0].toIntOrNull() ?: return@forEachIndexed
            val minute = parts[1].toIntOrNull() ?: return@forEachIndexed
            val target = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
            }
            if (target.after(now) && target.timeInMillis < nextMillis) {
                nextMillis = target.timeInMillis
                nextIndex = index
            }
        }

        val cards = listOf(binding.cardFajr, binding.cardDhuhr, binding.cardAsr, binding.cardMaghrib, binding.cardIsha)
        cards.forEachIndexed { index, card ->
            card.root.setBackgroundResource(
                if (index == nextIndex) R.drawable.card_background_highlight else R.drawable.card_background
            )
        }

        if (nextIndex == -1) {
            binding.countdown.text = "--:--:--"
            return
        }

        val diff = (nextMillis - now.timeInMillis) / 1000
        val h = diff / 3600
        val m = (diff % 3600) / 60
        val s = diff % 60
        binding.countdown.text = String.format("%02d:%02d:%02d", h, m, s)
    }

    companion object {
        private const val REQUEST_CITY = 100
    }
}
