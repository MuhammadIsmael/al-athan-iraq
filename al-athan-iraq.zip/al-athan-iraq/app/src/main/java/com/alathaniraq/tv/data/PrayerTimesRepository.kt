package com.alathaniraq.tv.data

class PrayerTimesRepository(private val api: AladhanApi = AladhanApi.create()) {

    suspend fun fetchToday(city: City): Result<AladhanData> {
        return try {
            val response = api.getTimings(
                latitude = city.latitude,
                longitude = city.longitude,
                timestamp = System.currentTimeMillis() / 1000
            )
            val data = response.data
            if (data != null) Result.success(data) else Result.failure(IllegalStateException("Empty response"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
