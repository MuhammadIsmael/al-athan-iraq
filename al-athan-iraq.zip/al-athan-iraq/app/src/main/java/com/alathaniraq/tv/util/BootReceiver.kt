package com.alathaniraq.tv.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.alathaniraq.tv.ui.MainActivity

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // MainActivity re-fetches timings on launch and re-schedules today's alarms.
            // For a production app, replace this with a WorkManager periodic job that
            // re-fetches and re-schedules once per day without requiring the UI to open.
            val launch = Intent(context, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra("silent_boot_refresh", true)
            }
            context.startActivity(launch)
        }
    }
}
